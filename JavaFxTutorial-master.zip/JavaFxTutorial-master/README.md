# Practice JavaFx Tutorial Course
Step by step to build JavaFx Apps. Code files for YouTube tutorial, Check the videos tutorial <a href="https://www.youtube.com/watch?v=FEN0xA_fuqs&list=PLd5-bvEurdb_Tg4t-G5SM5wlmEHjUpH8G">here</a>
<br />
Follow me:<br />
	<a href="https://www.facebook.com/GeekHouari" target="_blank">Facebook personal page</a><br />
	<a href="https://www.facebook.com/1Coding" target="_blank">Facebook page</a><br />
	<a href="https://www.twitter.com/HouariZegai" target="_blank">Twitter personal account</a><br />
	<a href="https://www.youtube.com/HouariZegai">Youtube channel</a>
	
## Preview:

#### PieChart example:
<img src="https://github.com/HouariZegai/JavaFxTutorial/blob/master/imagesPreview/pieChart.PNG" />

#### BarChart example:
<img src="https://github.com/HouariZegai/JavaFxTutorial/blob/master/imagesPreview/barChart.PNG" />
